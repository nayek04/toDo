package com.example.todo;

import android.content.DialogInterface;

public interface OnDialogCloseListener {
    void onDialogClose(DialogInterface dialogInterface);
}
